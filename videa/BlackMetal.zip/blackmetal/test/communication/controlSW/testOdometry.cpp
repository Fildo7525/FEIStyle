#include "testOdometry.hpp"

double TestOdometry::testWrapAngle(double angle)
{
	return this->Odometry::wrapAngle(angle);
}

